const mongoose = require('mongoose');

const profileUserSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  due_date: {
    type: String, 
    required: true,
    default: () => new Date().getDate().toString() 
  },
  image:{
    type: String,
    required: false
  },
  fullName: {
    type: String,
    required: true
  },
  status:{
    type: String,
    enum: ['pending', 'confirmed', 'rejected'],
    default:"pending"
  }

}, { _id: false });

const ProfileSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  fullName: {
    type: String,
    required: true
  },
  
  mobileNumber: {
    type: String,
    required: true
  },

  termNcondition: {
    type: Boolean,
    required: true
  },

  image:{
    type: String,
    required: false
  },

  gender: {
    type: String,
    enum: ['male', 'female', 'other'],
    required: true
  },

  joining_date: {
    type: Date, 
    required: true,
    default:Date.now
  },

  due_date: {
    type: String, 
    required: true,
    default: () => new Date().getDate().toString() 
  },

  my_users: [profileUserSchema]
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  


});

module.exports = mongoose.model('Profile', ProfileSchema);
