const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const auth = require('../middleware/auth');
const multer = require('multer');
const multerS3 = require('multer-s3');
const aws = require('aws-sdk');




router.get('/', async (req, res, next) => {
  res.send({ message: 'API is working 🚀' });
});







const User = require('../models/user');
const Profile = require('../models/profile');







































 










aws.config.update({
  secretAccessKey: 'speauOpuinLb7UfffiFosnhw2M20BJFpO8jy3rYo',
  accessKeyId: 'AKIATED6U27GLRACNPXT',
  region: 'ap-south-1',
});


const s3 = new aws.S3();

const storage = multerS3({
  s3: s3,
  bucket: 'dhankosh',
  
  contentType: multerS3.AUTO_CONTENT_TYPE,
  key: function (req, file, cb) {
    cb(null, Date.now().toString() + '-' + file.originalname);
  },
});











const fileFilter = (req, file, cb) => {
  if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Only JPEG and PNG files are allowed.'), false);
  }
};


const upload = multer({
  storage: storage,
  limits: {
    fileSize: 1024 * 1024 * 5, 
  },
  fileFilter: fileFilter,
});

router.post('/upload', upload.single('file'), (req, res, next) => {
  const file = req.file;
  res.status(201).json({
    message: 'File uploaded successfully.',
    filename: file.key,
    url: file.location,
  });
});



















router.post('/signup', async (req, res) => {
  try {
    
    const {gender,email,password,fullName,mobileNumber,termNcondition } = req.body;
    const user = new User({ email, password });
    await user.save();

    
    
    const profile = new Profile({ user_id: user._id, fullName,gender,mobileNumber,termNcondition });
    await profile.save();

    res.status(201).json({ message: 'User created successfully' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    
    const token = jwt.sign({ userId: user._id }, "secret");
    res.json({ token });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.get('/protected', auth, (req, res) => {
  
  res.send(`Hello ${req.user.userId}`);
});


router.get('/profile', auth, async (req, res) => {
  try {
    
    
    const profile = await Profile.findOne({user_id:req.user.userId});
    
      const userHistory = [
    {
        name:"deepak singh",
        deposite:10.99,
        dateTime:"18-12-2022"
    },
    {
        name:"deepak singh",
        deposite:100.99,
        dateTime:"19-12-2022"
    },
    {
      name:"deepak singh",
      deposite:10.99,
      dateTime:"18-12-2022"
  },
  {
      name:"deepak singh",
      deposite:100.99,
      dateTime:"19-12-2022"
  },
    {
        name:"deepak singh",
        deposite:200.99,
        dateTime:"20-12-2022"
    },
    {
      name:"deepak singh",
      deposite:10.99,
      dateTime:"18-12-2022"
  },
  {
      name:"deepak singh",
      deposite:100.99,
      dateTime:"19-12-2022"
  },
  {
      name:"deepak singh",
      deposite:200.99,
      dateTime:"20-12-2022"
  }
  ]
    res.json({ fullName: profile.fullName,gender: profile.gender,mobileNumber: profile.mobileNumber,termNcondition: profile.termNcondition,userHistory:userHistory });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});




module.exports = router;