
const express = require("express");
const multer = require("multer");
const upload = multer({ dest: "uploads/" });

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));





app.post("/upload_files", upload.array("files"), uploadFiles);

function uploadFiles(req, res) {
    
    
    res.json({ message: "Successfully uploaded files" });
}
app.listen(3000, () => {
    
});