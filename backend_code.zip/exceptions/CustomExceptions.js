class UserNotFoundError extends Error {
    constructor(message) {
      super(message);
      this.name = "UserNotFoundError";
    }
  }
  
class ProfileNotFoundError extends Error {
    constructor(message) {
      super(message);
      this.name = "ProfileNotFoundError";
    }
  }


module.exports = {
  UserNotFoundError,
  ProfileNotFoundError
};