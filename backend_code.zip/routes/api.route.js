const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");
const auth = require("../middleware/auth");
const multer = require("multer");
const multerS3 = require("multer-s3");
const aws = require("aws-sdk");
const nodemailer = require("nodemailer");
const { Types } = require("mongoose");

const xlsx = require("xlsx");

router.get("/", async (req, res, next) => {
  res.send({ message: "API is working 🚀" });
});

const User = require("../models/user");
const Profile = require("../models/profile");
const TransactionHistory = require("../models/transaction");

aws.config.update({
  secretAccessKey: "speauOpuinLb7UfffiFosnhw2M20BJFpO8jy3rYo",
  accessKeyId: "AKIATED6U27GLRACNPXT",
  region: "ap-south-1",
});

const s3 = new aws.S3();

const uploadXlsx = multer({
  dest: "uploads_xlsx/",
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  },
});

router.get("/protected2", auth, (req, res) => {
  res.send(`Hello ${req.user.userId}`);
});



// router.post(
//   "/upload_xlsx",
//   auth,
//   uploadXlsx.single("file"),
//   function (req, res) {
//     const workbook = xlsx.readFile(req.file.path);

//     const sheet_name_list = workbook.SheetNames;
//     const data = xlsx.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);
//     console.log('HERE IS req.body data',req.body)
//     res.send(data);
//   }
// );

router.post(
  "/upload_xlsx",
  auth,
  uploadXlsx.single("file"),
  function (req, res) {
    const workbook = xlsx.readFile(req.file.path);

    const sheet_name_list = workbook.SheetNames;
    const data = xlsx.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);
    console.log('HERE IS req.body data',req.body)
    res.send(data);
  }
);

const storage = multerS3({
  s3: s3,
  bucket: "dhankosh",

  contentType: multerS3.AUTO_CONTENT_TYPE,
  key: function (req, file, cb) {
    cb(null, Date.now().toString() + "-" + file.originalname);
  },
});

const fileFilter = (req, file, cb) => {
  if (file.mimetype === "image/jpeg" || file.mimetype === "image/png") {
    cb(null, true);
  } else {
    cb(
      new Error("Invalid file type. Only JPEG and PNG files are allowed."),
      false
    );
  }
};

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 1024 * 1024 * 5,
  },
  fileFilter: fileFilter,
});

router.post("/upload", upload.single("file"), (req, res, next) => {
  const reqBody = req.body;
  const file = req.file;

  res.status(201).json({
    message: "File uploaded successfully.",
    filename: file.key,
    url: file.location,
  });
});

// router.get("/transactions/:userId", auth, (req, res, next) => {
//   try {
//     res.status(200).json({ message: "User Transactions fetched successfully" });
//   } catch (error) {
//     res.status(400).json({ message: error.message });
//   }
// });

router.post('/transaction', auth, async (req, res) => {
  try {
    const {
      user_id,
      amount,
      month
      
    } = req.body;
    const submitted_by = req.user.userId

    const transaction = new TransactionHistory({
      user_id,
      amount,
      month,
      status,
      submitted_by,
    });
    const savedTransaction = await transaction.save();

    res.status(201).json(savedTransaction);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});



router.post('/upload_bulk_add_transaction', auth,
uploadXlsx.single("file"),
async (req, res) => {
  try {
    const submitted_by = req.user.userId;
    // const transactions = req.body;
    
    const workbook = xlsx.readFile(req.file.path);
    const sheet_name_list = workbook.SheetNames;    
    const data = xlsx.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);
    const transactions = data
    // Validate the transactions array
    if (!Array.isArray(transactions)) {
      return res.status(400).json({ error: 'Invalid transactions data' });
    }

    // Create an array to store the saved transactions
    const savedTransactions = [];

    // Process each transaction and save them individually
    for (const transactionData of transactions) {
      const { user_id, amount, month, status } = transactionData;

      const transaction = new TransactionHistory({
        user_id,
        amount,
        month,
        status,
        submitted_by,
      });

      const savedTransaction = await transaction.save();
      savedTransactions.push(savedTransaction);
    }

    res.status(201).json(savedTransactions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/bulk_add_transactions', auth, async (req, res) => {
  try {
    const submitted_by = req.user.userId;
    const transactions = req.body;

    // Validate the transactions array
    if (!Array.isArray(transactions)) {
      return res.status(400).json({ error: 'Invalid transactions data' });
    }

    // Create an array to store the saved transactions
    const savedTransactions = [];

    // Process each transaction and save them individually
    for (const transactionData of transactions) {
      const { user_id, amount, month, status } = transactionData;

      const transaction = new TransactionHistory({
        user_id,
        amount,
        month,
        status,
        submitted_by,
      });

      const savedTransaction = await transaction.save();
      savedTransactions.push(savedTransaction);
    }

    res.status(201).json(savedTransactions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


router.get('/transaction', auth, async (req, res) => {
  try {
    const transactions = await TransactionHistory.find({ user_id: req.user.userId });
    res.json(transactions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


router.patch('/transaction/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const updatedTransaction = await TransactionHistory.findByIdAndUpdate(
      id,
      { status },
      { new: true }
    );

    if (!updatedTransaction) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    res.json(updatedTransaction);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/transactions', auth, async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;

    const options = {
      page: parseInt(page),
      limit: parseInt(limit),
      sort: { created_on: -1 }, // Sort by created_on field in descending order
      populate: 'user_id submitted_by', // Populate user_id and submitted_by fields with corresponding user data
    };

    const query = { user_id: req.user.userId };

    const transactions = await TransactionHistory.paginate(query, options);

    res.json(transactions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});




router.post("/signup", upload.single("file"), async (req, res) => {
  try {
    const location = req.file ? req.file.location : null;

    const {
      gender,
      email,
      password,
      fullName,
      mobileNumber,
      termNcondition,
      type,
    } = req.body;
    const user = new User({ email, password, type });
    await user.save();

    const profile = new Profile({
      user_id: user._id,
      image: location,
      fullName,
      gender,
      mobileNumber,
      termNcondition,
    });
    await profile.save();

    res.status(201).json({ message: "User created successfully" });
  } catch (error) {
    res.status(400).json({ message: error.message });
    res.status(500).json({ message: "internal server error" });
  }
});

router.get("/send_email", async (req, res) => {
  try {
    let transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 465,
      secure: true,
      auth: {
        user: "djangoboy.18feb@gmail.com",
        pass: "pgeqjxjrovtvnocl",
      },
    });

    let mailOptions = {
      from: "djangoboy.18feb@gmail.com",
      to: "deepaksingh.18feb@gmail.com",
      subject: "Dhankosh Signup OTP",
      html: `<img src="cid:image1"/><p><b>Please find your OTP HERE</b></p><p><i>OTP</i> - <b>123456</b></p>`,
      attachments: [
        {
          filename: "image.jpg",
          path: "https://images.pexels.com/photos/8292851/pexels-photo-8292851.jpeg?auto=compress&cs=tinysrgb&w=500",
          cid: "image1",
        },
      ],
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        return;
      }
    });
    res.status(201).json({ message: "Send Email successfully" });
  } catch (error) {
    res.status(400).json({ message: error.message });
    res.status(500).json({ message: "internal server error" });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ message: "Invalid credentials" });
    }
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ userId: user._id, userType: user.type }, "secret");
    res.json({ token });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.get("/protected", auth, (req, res) => {
  res.send(`Hello ${req.user.userId}`);
});

class UserNotFoundError extends Error {
  constructor(message) {
    super(message);
    this.name = "UserNotFoundError";
  }
}

class ProfileNotFoundError extends Error {
  constructor(message) {
    super(message);
    this.name = "ProfileNotFoundError";
  }
}

router.post("/add_user_to_vendor", auth, async (req, res) => {
  try {
    const { user_id } = req.body;

    let user;
    let profile;
    try {
      user = await User.findOne({ _id: user_id });
      profile = await Profile.findOne({ user_id: user._id });
    } catch (error) {
      return res.status(404).json({ message: "User not found" });
    }
    const loggedInProfile = await Profile.findOne({ user_id: req.user.userId });

    if (!loggedInProfile) {
      return res.status(404).json({ message: "loggedIn Profile not found" });
    }
    loggedInProfile.my_users.push({
      user_id: user._id,
      due_date: profile.due_date,
      fullName: profile.fullName,
      image: profile.image,
    });
    await loggedInProfile.save();

    res.status(201).json({ message: "User added successfully" });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.post("/respond_vendor_req", auth, async (req, res) => {
  try {
    const { vendor_profile_id } = req.body;

    let profile;
    try {
      profile = await Profile.findOne({ _id: vendor_profile_id });
      const confirmedUser = profile.my_users.find(
        (user) => user.user_id == req.user.userId
      );
      if (confirmedUser) {
        confirmedUser.status = "confirmed";
        await profile.save();
      }
    } catch (error) {
      return res.status(404).json({ message: "Profile not found" });
    }

    res.status(201).json({ message: "Response saved successfully" });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.get("/my_profile", auth, async (req, res) => {
  try {
    const profile = await Profile.findOne({ user_id: req.user.userId });

    let final_obj = {
      fullName: profile.fullName,
      gender: profile.gender,
      mobileNumber: profile.mobileNumber,
      image: profile.image,
      termNcondition: profile.termNcondition,
    };

    if (req.user.userType == "Vendor") {
      final_obj["userHistory"] = profile.my_users;
    }

    res.status(200).json({ data: final_obj });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.get("/profile/:id", auth, async (req, res) => {
  try {

    const loggedInProfile = await Profile.findOne({ user_id: req.user.userId });
    const profile = await Profile.findOne({ _id: req.params.id });
    if (!profile){
      res.status(400).json({ message: 'profile id did not match any record!' });

    }
    console.log('profile',profile.user_id,loggedInProfile.my_users)
    const confirmedUser = loggedInProfile.my_users.find(
      (user) => user.user_id.equals(profile.user_id)
    );
    console.log('confirmedUser',confirmedUser)
    if (!confirmedUser){
    res.status(400).json({ message: 'You dont seem to be authorized!' });

    }

    
    else{
      res.json(profile);
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;
