const jwt = require('jsonwebtoken');

const auth = (req, res, next) => {
  

  
  try {
    const authorization = req.header('Authorization')
    
    const token = authorization.replace('Bearer ', '');
    const decoded = jwt.verify(token, 'secret');
    req.user = decoded;
    next();
    
  } catch (error) {
    
    res.status(401).send({ error: 'Unauthorized' });
  }
};

module.exports = auth;
